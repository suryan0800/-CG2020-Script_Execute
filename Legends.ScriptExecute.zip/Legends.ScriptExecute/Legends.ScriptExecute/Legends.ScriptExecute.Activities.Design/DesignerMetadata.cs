using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using Legends.ScriptExecute.Activities.Design.Designers;
using Legends.ScriptExecute.Activities.Design.Properties;

namespace Legends.ScriptExecute.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(ScriptExecutor), categoryAttribute);
            builder.AddCustomAttributes(typeof(ScriptExecutor), new DesignerAttribute(typeof(ScriptExecutorDesigner)));
            builder.AddCustomAttributes(typeof(ScriptExecutor), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(UnzipFile), categoryAttribute);
            builder.AddCustomAttributes(typeof(UnzipFile), new DesignerAttribute(typeof(UnzipFileDesigner)));
            builder.AddCustomAttributes(typeof(UnzipFile), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(ZipAFolderOrFile), categoryAttribute);
            builder.AddCustomAttributes(typeof(ZipAFolderOrFile), new DesignerAttribute(typeof(ZipAFolderOrFileDesigner)));
            builder.AddCustomAttributes(typeof(ZipAFolderOrFile), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
