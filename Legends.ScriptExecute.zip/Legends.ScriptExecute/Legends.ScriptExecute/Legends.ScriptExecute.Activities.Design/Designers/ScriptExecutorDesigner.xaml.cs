namespace Legends.ScriptExecute.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for ScriptExecutorDesigner.xaml
    /// </summary>
    public partial class ScriptExecutorDesigner
    {
        public ScriptExecutorDesigner()
        {
            InitializeComponent();
        }
    }
}
