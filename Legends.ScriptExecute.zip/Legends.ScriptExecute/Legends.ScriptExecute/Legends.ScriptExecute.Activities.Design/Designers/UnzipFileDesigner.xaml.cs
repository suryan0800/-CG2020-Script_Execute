namespace Legends.ScriptExecute.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UnzipFileDesigner.xaml
    /// </summary>
    public partial class UnzipFileDesigner
    {
        public UnzipFileDesigner()
        {
            InitializeComponent();
        }
    }
}
