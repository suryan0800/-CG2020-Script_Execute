namespace Legends.ScriptExecute.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for ZipAFolderOrFileDesigner.xaml
    /// </summary>
    public partial class ZipAFolderOrFileDesigner
    {
        public ZipAFolderOrFileDesigner()
        {
            InitializeComponent();
        }
    }
}
