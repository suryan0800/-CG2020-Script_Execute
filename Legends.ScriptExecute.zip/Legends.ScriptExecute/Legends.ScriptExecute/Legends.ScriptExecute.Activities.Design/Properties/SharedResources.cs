﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Legends.ScriptExecute.Activities.Design.Properties.Resources
    {
    }
}