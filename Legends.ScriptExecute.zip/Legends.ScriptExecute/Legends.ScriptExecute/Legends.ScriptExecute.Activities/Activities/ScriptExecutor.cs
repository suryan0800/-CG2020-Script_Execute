using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using Legends.ScriptExecute.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.Diagnostics;
using System.Windows.Markup;
using System.IO;

namespace Legends.ScriptExecute.Activities
{
    [LocalizedDisplayName(nameof(Resources.ScriptExecutor_DisplayName))]
    [LocalizedDescription(nameof(Resources.ScriptExecutor_Description))]
    public class ScriptExecutor : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.ScriptExecutor_ProgramName_DisplayName))]
        [LocalizedDescription(nameof(Resources.ScriptExecutor_ProgramName_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> ProgramName { get; set; }

        [LocalizedDisplayName(nameof(Resources.ScriptExecutor_ScriptFile_DisplayName))]
        [LocalizedDescription(nameof(Resources.ScriptExecutor_ScriptFile_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> ScriptFile { get; set; }

        [LocalizedDisplayName(nameof(Resources.ScriptExecutor_InputFile_DisplayName))]
        [LocalizedDescription(nameof(Resources.ScriptExecutor_InputFile_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> InputFile { get; set; }

        [LocalizedDisplayName(nameof(Resources.ScriptExecutor_Output_DisplayName))]
        [LocalizedDescription(nameof(Resources.ScriptExecutor_Output_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Output { get; set; }

        [LocalizedDisplayName(nameof(Resources.ScriptExecutor_Error_DisplayName))]
        [LocalizedDescription(nameof(Resources.ScriptExecutor_Error_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<bool> Error { get; set; }

        #endregion


        #region Constructors

        public ScriptExecutor()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (ProgramName == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(ProgramName)));
            //if (ScriptFile == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(ScriptFile)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            String programName = ProgramName.Get(context);
            String scriptFile = ScriptFile.Get(context);
            String inputFile = InputFile.Get(context);

            ///////////////////////////
            // Add execution logic HERE
            ///////////////////////////
            try
            {
                Process prss = new Process();

                //strCommand is path and file name of command to run
                prss.StartInfo.FileName = "CMD.exe";

                //strCommandParameters are parameters to pass to program
                if (File.Exists(scriptFile))
                {
                    String s = String.Format("/C {0} \"{1}\"", programName.Trim(), @scriptFile);
                    
                    //Console.WriteLine(s);
                    if(File.Exists(inputFile))
                    {
                        s = String.Format("/C {0} \"{1}\" < \"{2}\"", programName.Trim(), @scriptFile, @inputFile);
                    }
                    else
                    {
                        s = String.Format("/C {0} \"{1}\" {2}", programName.Trim(), @scriptFile, @inputFile);
                    }
                    prss.StartInfo.Arguments = s;
                    prss.StartInfo.WorkingDirectory = Path.GetDirectoryName(scriptFile);

                }
                else
                {
                    String s = String.Format("/C {0}", programName.Trim());
                    prss.StartInfo.Arguments = s;
                    /*
                    return (ctx) =>
                    {
                        Output.Set(ctx, "File Not Exists");
                        Error.Set(ctx, false);
                    };
                    */
                }

                

                prss.StartInfo.UseShellExecute = false;

                //Set output of program to be written to process output stream
                prss.StartInfo.RedirectStandardOutput = true;

                //Optional
                //prss.StartInfo.WorkingDirectory = strWorkingDirectory;

                //Visibility of Command prompt window
                prss.StartInfo.CreateNoWindow = true;
                //prss.StartInfo.CreateNoWindow = true;

                //Start the process
                prss.Start();

                //Get program output
                string strOutput = prss.StandardOutput.ReadToEnd();

                //Console.WriteLine("Hello World!");
                //Console.WriteLine(strOutput);
                //Wait for process to finish
                prss.WaitForExit();
                //strOutput = "WHy SAstra";
                // Outputs
                return (ctx) =>
                {
                    Output.Set(ctx,strOutput);
                    Error.Set(ctx, true);
                };
            }catch(Exception e)
            {
                return (ctx) =>
                {
                    Output.Set(ctx, e.ToString());
                    Error.Set(ctx, false);
                };
            }
        }

        #endregion
    }
}

