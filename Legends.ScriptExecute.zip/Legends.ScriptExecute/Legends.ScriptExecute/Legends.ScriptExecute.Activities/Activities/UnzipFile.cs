using System;
using System.Activities;
using System.IO;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using Legends.ScriptExecute.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;


namespace Legends.ScriptExecute.Activities
{
    [LocalizedDisplayName(nameof(Resources.UnzipFile_DisplayName))]
    [LocalizedDescription(nameof(Resources.UnzipFile_Description))]
    public class UnzipFile : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.UnzipFile_ZipFile_DisplayName))]
        [LocalizedDescription(nameof(Resources.UnzipFile_ZipFile_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> ZipFile { get; set; }

        [LocalizedDisplayName(nameof(Resources.UnzipFile_Destination_DisplayName))]
        [LocalizedDescription(nameof(Resources.UnzipFile_Destination_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Destination { get; set; }

        [LocalizedDisplayName(nameof(Resources.UnzipFile_Completion_DisplayName))]
        [LocalizedDescription(nameof(Resources.UnzipFile_Completion_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<bool> Completion { get; set; }

        #endregion


        #region Constructors

        public UnzipFile()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (ZipFile == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(ZipFile)));
            if (Destination == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Destination)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var zipFile = ZipFile.Get(context);
            var destination = Destination.Get(context);

            ///////////////////////////
            // Add execution logic HERE
            ///////////////////////////
            try
            {
                
               
                System.IO.Compression.ZipFile.ExtractToDirectory(@zipFile, @destination);
                // Outputs
                return (ctx) =>
                {
                    Completion.Set(ctx, true);
                };
            }catch(Exception e)
            {
                return (ctx) =>
                {
                    Completion.Set(ctx, false);
                };
            }
        }

        #endregion
    }
}

