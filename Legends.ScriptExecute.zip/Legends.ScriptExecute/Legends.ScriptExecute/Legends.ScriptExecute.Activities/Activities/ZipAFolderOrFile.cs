using System;
using System.Activities;
using System.Activities.Expressions;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Legends.ScriptExecute.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace Legends.ScriptExecute.Activities
{
    [LocalizedDisplayName(nameof(Resources.ZipAFolderOrFile_DisplayName))]
    [LocalizedDescription(nameof(Resources.ZipAFolderOrFile_Description))]
    public class ZipAFolderOrFile : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.ZipAFolderOrFile_Path_DisplayName))]
        [LocalizedDescription(nameof(Resources.ZipAFolderOrFile_Path_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Path { get; set; }

        [LocalizedDisplayName(nameof(Resources.ZipAFolderOrFile_Destination_DisplayName))]
        [LocalizedDescription(nameof(Resources.ZipAFolderOrFile_Destination_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Destination { get; set; }

        [LocalizedDisplayName(nameof(Resources.ZipAFolderOrFile_Completion_DisplayName))]
        [LocalizedDescription(nameof(Resources.ZipAFolderOrFile_Completion_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<bool> Completion { get; set; }

        #endregion


        #region Constructors

        public ZipAFolderOrFile()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Path == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Path)));
            if (Destination == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Destination)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var path = Path.Get(context);
            var destination = Destination.Get(context);

            ///////////////////////////
            // Add execution logic HERE
            ///////////////////////////
            try
            {
                if (File.Exists(destination))
                {
                    File.Delete(destination);
                }

                System.IO.Compression.ZipFile.CreateFromDirectory(@path, @destination);

                // Outputs
                return (ctx) =>
                {
                    Completion.Set(ctx, true);
                };
                
            }catch(Exception e)
            {
                return (ctx) =>
                {
                    Completion.Set(ctx, false);
                };
            }
        }

        #endregion
    }
}

