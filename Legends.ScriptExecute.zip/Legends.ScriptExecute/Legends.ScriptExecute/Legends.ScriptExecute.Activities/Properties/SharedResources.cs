﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Legends.ScriptExecute.Activities.Properties.Resources
    {
    }
}